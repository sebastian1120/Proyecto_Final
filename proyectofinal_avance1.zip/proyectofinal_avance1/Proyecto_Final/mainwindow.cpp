#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->resize(1599,899);
    this->escena = new QGraphicsScene(this);
    ui->graphicsView->setScene(escena);

    this->vista = new QGraphicsView(this);
    vista->resize(0,0);

    QImage MenuF(":/Imagenes/inicio1.jpg");
    escena->setSceneRect(0,0,MenuF.width(),MenuF.height());
    ui->graphicsView->setBackgroundBrush(QBrush(MenuF));

    botonlvl1 = new QPushButton();
    botonlvl2 = new QPushButton();

    estiloBotonlvl1 = "QPushButton {"
                   "background-image: url(:/Imagenes/nivel_1.jpg);"
                   "background-repeat: no-repeat;"
                   "background-position: center;"
                   "border: 5px solid #000000;"
                   "width: 261px;"
                   "height: 293px;"
                   "}";

    estiloBotonlvl2 = "QPushButton {"
                   "background-image: url(:/Imagenes/nivel_2.jpg);"
                   "background-repeat: no-repeat;"
                   "background-position: center;"
                   "border: 5px solid #000000;"
                   "width: 261px;"
                   "height: 293px;"
                   "}";

    botonlvl1->setStyleSheet(estiloBotonlvl1);
    botonlvl2->setStyleSheet(estiloBotonlvl2);

    QGraphicsProxyWidget *proxy1 = escena->addWidget(botonlvl1);
    QGraphicsProxyWidget *proxy2 = escena->addWidget(botonlvl2);
    proxy1->setPos(90, 510);
    proxy2->setPos(432, 510);

    connect(botonlvl1, &QPushButton::clicked, this, &MainWindow::Nivel1);
    connect(botonlvl2, &QPushButton::clicked, this, &MainWindow::Nivel2);

}

void MainWindow::Nivel1()
{
    lvl1 = new QGraphicsScene(this);

    QImage background(":/Imagenes/sala.jpg");
    lvl1->setBackgroundBrush(QBrush(background));
    lvl1->setSceneRect(0, 0, background.width(), background.height());

    vista->setScene(lvl1);
    vista->resize(background.width()+4,background.height()+4);
}

void MainWindow::Nivel2()
{
    lvl2 = new QGraphicsScene(this);

    QImage background(":/Imagenes/Fondo2.png");
    lvl2->setBackgroundBrush(QBrush(background));
    lvl2->setSceneRect(0, 0, background.width(), background.height());

    vista->setScene(lvl2);
    vista->resize(background.width()+4,background.height()+4);
}

MainWindow::~MainWindow()
{
    delete ui;
}
